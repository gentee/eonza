
# Eonza-assets

Static web-files for [eonza](https://github.com/gentee/eonza) automation application.  
These files are embedded into eonza executable file.
