# eonza-scripts
Scripts for [Eonza automation](https://www.eonza.org) software.
